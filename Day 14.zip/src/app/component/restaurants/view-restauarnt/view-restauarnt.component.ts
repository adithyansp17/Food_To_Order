import { Component } from '@angular/core';

@Component({
  selector: 'app-view-restauarnt',
  templateUrl: './view-restauarnt.component.html',
  styleUrl: './view-restauarnt.component.scss'
})
export class ViewRestauarntComponent {

}
