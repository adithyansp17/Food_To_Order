import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-restauarnt',
  templateUrl: './edit-restauarnt.component.html',
  styleUrl: './edit-restauarnt.component.scss'
})
export class EditRestauarntComponent {

}
